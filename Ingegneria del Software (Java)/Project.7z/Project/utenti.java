package Project;

public class utenti {
    public String nome;
    public String cognome;
    public String email;
    public String password;
    public boolean isadmin;

     utenti(){
       nome=""; cognome="";email="";password="";isadmin=false;}
}
