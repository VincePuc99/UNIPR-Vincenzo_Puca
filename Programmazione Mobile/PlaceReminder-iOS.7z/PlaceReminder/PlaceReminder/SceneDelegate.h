//
//  SceneDelegate.h
//  PlaceReminder
//
//  Created by Vincenzo Puca on 07/06/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

