//
//  CustomAnnotation.m
//  PlaceReminder
//
//  Created by Vincenzo Puca on 08/06/23.
//

#import <Foundation/Foundation.h>
#import "CustomAnnotation.h"

@implementation CustomAnnotation

@end
